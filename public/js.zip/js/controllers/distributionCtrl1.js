/**
 * Created by kelvin on 1/30/15.
 */
angular.module('malariaApp').controller('distributionCtrl1',function($scope,$http){

})