/**
 * Created by kelvin on 3/2/15.
 */
angular.module('malariaApp').controller('settingsCtrl',function($scope,$http){

})